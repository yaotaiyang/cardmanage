解压后的文件包括：

av.js           未经压缩的完整的 JavaScript SDK
av-mini.js      经过压缩的完整的 JavaScript SDK
av-core.js      未经压缩的包含核心功能的 JavaScript SDK
av-core-mini.js 压缩后的包含核心功能的 JavaScript SDK

av.js 和 av-core.js 的主要区别是后者不包括 BackBone.js 的一些支持，如 AV.View、 AV.Collection、AV.Router 等，相对地，文件会更小一些。

快速入门： https://leancloud.cn/start.html
开发指南： https://leancloud.cn/docs/js_guide.html
技术支持:  https://ticket.avosapps.com/

感谢您对 LeanCloud 的支持，有任何疑问都可以到提交工单获取帮助。
